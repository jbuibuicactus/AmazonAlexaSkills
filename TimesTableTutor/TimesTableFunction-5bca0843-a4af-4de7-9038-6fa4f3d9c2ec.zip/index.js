/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';

const Alexa = require('alexa-sdk');
// This is the intial welcome message
    var welcomeMessage = "Welcome to Triple Tee, the Times Table Tutor! Are you ready to begin?";
    var repeatWelcomeMessage = "Say yes to start or no to quit.";
var states = {
    STARTMODE: '_STARTMODE',
    ASKMODE: '_ASKMODE',
    PREPMODE: '_PREPMODE',
    QUESTIONMODE: '_QUESTIONMODE'
    
};
var positiveresponse = ["WOW! Nice Job!", "Great work!", "That's right!", "Correct!", "Good job!", "Smart!", "Nice!", "Impressive!", "Good work!"];
var negativeresponse = ["Aw man, sorry that's wrong, try again", "Sorry, that's incorrect, try again", "try again", "Whoops, try again", "Uh oh, I'm sorry that's wrong, try again."];
var errormessage = "I'm sorry, I didn't understand that, say again.";
var numberofquestions = 0;
var practicenumber = 0;
var randomnumber = 0;
var usednumbers = [];
var goodbyeMessage = "Ok, see you next time!";
exports.handler = function (event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(newSessionHandler, startGameHandlers, askQuestionHandlers, askQuestionHandlers1, askQuestionHandlers2);
    alexa.execute();
};

// set state to start up and  welcome the user
var newSessionHandler = {
  'LaunchRequest': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', welcomeMessage, repeatWelcomeMessage);
  },'AMAZON.HelpIntent': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', "Are you ready to start practicing your multiplication tables?", "Are you ready to start practicing your multiplication tables?");
  },
  'Unhandled': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', "Are you ready to start practicing your multiplication tables?", "Are you ready to start practicing your multiplication tables?");
  }
};
var startGameHandlers = Alexa.CreateStateHandler(states.STARTMODE, {
    'AMAZON.ResumeIntent': function () {

       

        // set state to asking questions
        this.handler.state = states.PREPMODE;

        // ask first question, the response will be handled in the askQuestionHandler
        var message = "For what number would you like to practice your times tables?";


        // ask the first question
        this.emit(':ask', message, message);
    },
    'AMAZON.PauseIntent': function () {
        // Handle No intent.
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
         this.emit(':ask', "Are you ready to start practicing your multiplication tables?", "Are you ready to start practicing your multiplication tables?");
    },
    'AMAZON.HelpIntent': function () {
        this.emit(':ask', "Are you ready to start practicing your multiplication tables?", "Are you ready to start practicing your multiplication tables?");
    },
    'Unhandled': function () {
        this.emit(':ask', "Are you ready to start practicing your multiplication tables?", "Are you ready to start practicing your multiplication tables?");
    }
});

var askQuestionHandlers = Alexa.CreateStateHandler(states.PREPMODE, {
    
    'NumberIntent': function() {
        if(true) {
            var elem = this.event.request.intent.slots.Number.value;
            practicenumber = Number(elem);
            this.handler.state = states.ASKMODE;
            var message = "How many questions would you like to be asked?";
            this.emit(':ask', message, message);
        }else {
            this.emit(':tell', "I'm sorry, I didn't understand that, please ask again");
        }
    },

    
    
    
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
        // reset the game state to start mode
        this.handler.state = states.STARTMODE;
        this.emit(':ask', welcomeMessage, repeatWelcomeMessage);
    },
    'Unhandled': function () {
        this.emit(':ask', errormessage, errormessage);
    }
});

var askQuestionHandlers1 = Alexa.CreateStateHandler(states.ASKMODE, {
    
    'NumberIntent': function() {
        if(true) {
            var elem = this.event.request.intent.slots.Number.value;
            numberofquestions = Number(elem);
            this.handler.state = states.QUESTIONMODE;
            randomnumber = Math.floor((Math.random() * 20) + 1);
            usednumbers.push(randomnumber);
            numberofquestions = numberofquestions - 1;
            var message = "What is the product of " + practicenumber +" and " + randomnumber + "?";
            this.emit(':ask', message, message);
        }else {
            this.emit(':ask', "I'm sorry, I didn't understand that, please ask again");
        }
    },

    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
        // reset the game state to start mode
        this.handler.state = states.STARTMODE;
        this.emit(':ask', welcomeMessage, repeatWelcomeMessage);
    },
    'Unhandled': function () {
        this.emit(':ask', errormessage, errormessage);
    }
});
var askQuestionHandlers2 = Alexa.CreateStateHandler(states.QUESTIONMODE, {
    
    'NumberIntent': function() {
        //this.emit('tell', "number intent issue");
        if(true) {
            //this.emit('tell', 'hello');
            var elem = this.event.request.intent.slots.Number.value;
            var useranswer = Number(elem);
            
            if(useranswer == practicenumber * randomnumber) {
                var mynewrand = Math.floor(Math.random() * positiveresponse.length)
                var message = positiveresponse[mynewrand];
                if (numberofquestions === 0) {
                    message = message + "Would you like to play again?";
                    this.handler.state = states.STARTMODE;
                    this.emit(':ask', message, message);
                } else {
                    var keeper = true;
                    while (keeper) {
                        randomnumber = Math.floor((Math.random() * 20) + 1);
                        keeper = false;
                        for( var i = 0; i < usednumbers.length; i++){
                            if (usednumbers[i] == randomnumber) {
                                keeper = true;
                            }
                        }
                    }
                    usednumbers.push(randomnumber);
                    message = message + "What is the product of " + practicenumber +" and " + randomnumber + "?";
                    numberofquestions = numberofquestions - 1;
                    this.emit(':ask',message, message);
                    
                }
            }else {
                var mynewrandom = Math.floor(Math.random() * negativeresponse.length)
                var incorrectmessage = negativeresponse[mynewrandom];
                this.emit(':ask', incorrectmessage, incorrectmessage);
            }
            
        }else {
            this.emit(':tell', "I'm sorry, I didn't understand that, please ask again");
        }
    },

    
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
        // reset the game state to start mode
        this.handler.state = states.STARTMODE;
        this.emit(':ask', welcomeMessage, repeatWelcomeMessage);
    },
    'Unhandled': function () {
        this.emit(':ask', errormessage, errormessage);
    }
});


function isAnswerSlotValid(intent) {
    var answerSlotFilled = intent && intent.slots && intent.slots.Number && intent.slots.Number.value;
    return answerSlotFilled;
}


