'use strict';
var Alexa = require('alexa-sdk');

//=========================================================================================================================================
//TODO: The items below this comment need your attention.
//=========================================================================================================================================

//Replace with your app ID (OPTIONAL).  You can find this value at the top of your skill's page on http://developer.amazon.com.  
//Make sure to enclose your value in quotes, like this: var APP_ID = "amzn1.ask.skill.bb4045e6-b3e8-4133-b650-72923c5980f1";
var APP_ID =  "amzn1.ask.skill.1fe4da03-2c4f-4d1a-9b8f-e9ee4b34e803";

var SKILL_NAME = "Chemistry Information";
var GET_FACT_MESSAGE = "Here's your information for ";
var HELP_MESSAGE = "Ask me for information about an element. For example, you can say 'Tell me about Carbon', or, 'tell me about Nitrogen.' If you want to exit, you can say exit... What can I help you with?";
var HELP_REPROMPT = "What can I help you with?";
var STOP_MESSAGE = "Goodbye!";

//=========================================================================================================================================
//TODO: Replace this data with your own.  You can find translations of this data at http://github.com/alexa/skill-sample-node-js-fact/data
//=========================================================================================================================================

// [Chemical Symbol, Atomic Number, Atomic mass, number of protons, number of electrons, number of neutrons, most common in]
var hydrogen = ["H", 1, 1.00794, 1, 1, 0];
var helium = ["H E.", 2, "4.002602", 2, 2, 2];
var lithium = ["L I.", 3, "6.941", 3, 3, 4];
var beryllium = ["B E.", 4, "9.01218", 4, 4, 5];
var boron = ["B", 5, "10.811", 5, 5, 5];
var carbon = ["C", "6", "12.0107", 6, 6, 6];
var nitrogen = ["N", 7, "14.0067", 7,7,7];
var oxygen = ["O", 8, "15.999", 8,8,8];
var fluorine = ["F", 9, "18.9984", 9, 9, 10];
var neon = ["N E.", 10, "20.1797", 10,10,10];
var sodium = ["N A.", 11, "22.9898", 11, 11, 12];
var magnesium = ["M G.", 12, "24.3050", 12, 12, 12];
var aluminum = ["A L.", 13, "26.8815", 13, 13, 14];
var silicon = ["S I.", 14, "28.0855", 14, 14, 14];
var phosphorous = ["P", 15, "30.9738", 15, 15, 16];
var sulfur = ["S", 16, "32.065", 16, 16, 16];
var chlorine = ["C L.", 17, "35.453", 17, 17, 18];
var argon = ["A R.", 18, "39.948", 18,18, 22];
var potassium = ["K", 19, "39,0983", 19, 19, 20];
var calcium = ["C A.", 20, "40.078", 20,20,20];
var scandium = ["S C.", 21, "44.9559", 21, 21, 24];
var titanium = ["T I.", 22, "47.867", 22, 22, 26];
var vanadium = ["V", 23, "50.9415", 23, 23, 28];
var chromium = ["C R.", 24, "51.9961", 24, 24, 28];
var manganese = ["M N.", 25, "54.9380", 25, 25, 30];
var iron = ["F E.", 26, "55.845", 26, 26, 30];
var cobalt = ["C O.", 27, "58.9332", 27, 27, 32];
var nickel = ["N I.", 28, "58.6934", 28, 28, 31];
var copper = ["C U.", 29, "63.546", 29,29, 35];
var zinc = ["Z N.", 30, "65.38", 30, 30, 35];
var gallium = ["G A.", 31, "69.723", 31, 31, 39];
var germanium = ["G E.", 32, "72.64", 32, 32, 41];
var arsenic = ["A S.", 33, "74.9216", 33, 33, 42];
var selenium = ["S E.", 34, "78.96", 34, 34, 45];
var bromine = ["B R.", 35, "79.904", 35, 35, 45];
var krypton = ["K R.", 36, "83.798", 36, 36, 48];
var rubidium = ["R B.", 37, "85.4678", 37, 37, 48];
var strontium = ["S R.", 38, "87.62", 38, 38, 50];
var yttrium = ["Y", 39, "88.90585", 39, 39, 50];
var zirconium = ["Z R.", 40, "91.224", 40, 40, 51];
var niobium = ["N B.", 41, "92.9064", 41, 41, 52];
var molybdenum = ["M O.", 42, "95.96", 42, 42, 54];
var technetium = ["T C.", 43, "97.9072", 43, 43, 55];
var ruthenium = ["R U.", 44, 101.07, 44,44,57];
var rhodium = ["R H.", 45, 102.9055, 45, 45,58];
var palladium = ["P D.", 46, 106.42,46,46,60];
var silver = ["A G.", 47, 107.8682, 47, 47, 61];
var cadmium = ["C D.", 48, 112.411, 48, 48, 64];
var indium = ["I N.", 49, 114.818, 49, 49, 66];
var tin = ["S N.", 50, 118.710, 50, 50, 69];
var antimony = ["S B.", 51, 121.760, 51, 51, 71];
var tellurium = ["T E.", 52, 127.60, 52, 52, 76];
var iodine = ["I", 53, 126.9048, 53, 53, 74];
var xenon = ["X E.", 54, 131.293, 54, 54, 77];
var cesium = ["C S.", 55, 132.9054, 55, 55, 78];
var barium = ["B A.", 56, 137.327, 56, 56, 81];
var lanthanum = ["L A.", 57, 138.9055, 57, 57, 82];
var cerium = ["C E.", 58, 140.116, 58, 58, 82];
var praseodymium = ["P R.", 59, 140.90765, 59, 59, 81];
var neodymium = ["N D.", 60, 144.242, 60, 60, 84];
var promethium = ["P M.", 61, 145, 61, 61, 85];
var samarium = ["S M.", 62, 150.36, 62, 62, 88];
var europium = ["E U.", 63, 151.964, 63, 63, 89];
var gadolinium = ["G D.", 64, 157.25, 64, 64, 93];
var terbium = ["T B.", 65, 158.92535, 65, 65, 94];
var dysprosium = ["D Y.", 66, 162.500, 66, 66, 97];
var holmium = ["H O.", 67, 164.9303, 67, 67, 98];
var erbium = ["E R.", 68, 167.259, 68, 68, 99];
var thulium = ["T M.", 69, 168.9342, 69, 69, 100];
var ytterbium = ["Y B.", 70, 173.054, 70, 70, 103];
var lutetium = ["L U.", 71, 174.9668, 71, 71, 104];
var hafnium = ["H F.", 72, 178.49, 72, 72, 106];
var tantalum = ["T A.", 73, 180.94788, 73, 73, 108];
var tungsten = ["W", 74, 183.84, 74, 74, 110];
var rhenium = ["R E.", 75, 186.207, 75, 75, 111];
var osmium = ["O S.", 76, 190.23, 76, 76, 114];
var iridium = ["I R.", 77, 192.217, 77, 77, 115];
var platinum = ["P T.", 78, 195.084, 78, 78, 117];
var gold = ["A U.", 79, 196.96657, 79, 79 , 120];
var mercury = ["H G.", 80, 200.59, 80, 80, 121];
var thallium = ["T L.", 81, 204.3833, 81, 81, 123];
var lead = ["P B.", 82, 207.2, 82, 82, 125];
var bismuth = ["B I.", 83, 208.9804, 83, 83, 126];
var polonium = ["P O.", 84, 208.9824, 84, 84, 125];
var astatine = ["A T.", 85, 209.9871, 85, 85, 125];
var radon = ["R N.", 86, 222.0176, 86, 86, 136];
var francium = ["F R.", 87, 223, 87, 87, 136];
var radium = ["R A.", 88, 226, 88, 88, 138];
var actinium = ["A C.", 89, 227, 89, 89, 138];
var thorium = ["T H.", 90, 232.03806, 90, 90, 142];
var protactinium = ["P A.", 91, 231.03588, 91, 91, 140];
var uranium = ["U", 92, 238.02891, 92, 92, 146];
var neptunium = ["N P.", 93, 237, 93, 93, 144];
var plutonium = ["P U.", 94, 244, 94, 94, 150];
var americium = ["A M.", 95, 243, 95, 95, 148];
var curium = ["C M.", 96, 247, 96, 96, 151];
var berkelium = ["B K.", 97, 247, 97, 97, 150];
var californium = ["C F.", 98, 251, 98, 98, 153];
var einsteinium = ["E S.", 99, 252, 99, 99, 153];
var fermium = ["F M.", 100, 257, 100, 100, 157];
var mendelevium = ["M D.", 101, 258, 101, 101, 157];
var nobelium = ["N O.", 102, 259, 102, 102, 157];
var lawrencium = ["L R.", 103, 262, 103, 103, 159];
var rutherfordium = ["R F.", 104, 261, 104, 104, 157];
var dubnium = ["D B.", 105, 262, 105, 105, 157];
var seaborgium = ["S G.", 106, 266, 106, 106, 160];
var bohrium = ["B H.", 107, 264, 107, 107, 157];
var hassium = ["H S.", 108, 277, 108, 108, 169];
var meitnerium = ["M T.", 109, 268, 109, 109, 159];
var darmstadtium = ["D S.", 110, 271, 110,110, 161];
var roentgenium = ["R G.", 111, 272, 111, 111, 161];
var ununbium = ["U U. B.", 112, 285, 112, 112, 173];
var ununtrium = ["U U. T.", 113, 284, 113, 113, 171];
var ununquadium = ["U. U. Q", 114, 289, 114, 114, 175];
var ununpentium = ["U. U. P", 115, 288, 115, 115, 173];
var ununhexium = ["U. U. H", 116, 292, 116, 116, 176];
var ununseptium = ["U. U. S", 117, "Unknown", "Unknown", "Unknown", "Unknown"];
var ununoctium = ["U. U. O", 118, 294, 118, 118, 176]


var myMap = new Map();
myMap.set("hydrogen", hydrogen);
myMap.set("helium", helium);
myMap.set("lithium", lithium);
myMap.set("beryllium", beryllium);
myMap.set("boron", boron);
myMap.set("carbon", carbon);
myMap.set("nitrogen", nitrogen);
myMap.set("oxygen", oxygen);
myMap.set("fluorine", fluorine);
myMap.set("neon", neon);
myMap.set("sodium", sodium);
myMap.set("magnesium", magnesium);
myMap.set("aluminum", aluminum);
myMap.set("silicon", silicon);
myMap.set("phosphorous", phosphorous);
myMap.set("sulfur", sulfur);
myMap.set("chlorine", chlorine);
myMap.set("argon", argon);
myMap.set("potassium", potassium);
myMap.set("calcium", calcium);
myMap.set("scandium", scandium);
myMap.set("titanium", titanium);
myMap.set("vanadium", vanadium);
myMap.set("chromium", chromium);
myMap.set("manganese", manganese);
myMap.set("iron", iron);
myMap.set("cobalt", cobalt);
myMap.set("nickel", nickel);
myMap.set("copper", copper);
myMap.set("zinc", zinc);
myMap.set("gallium", gallium);
myMap.set("germanium", germanium);
myMap.set("arsenic", arsenic);
myMap.set("selenium", selenium);
myMap.set("bromine", bromine);
myMap.set("krypton", krypton);
myMap.set("rubidium", rubidium);
myMap.set("strontium", strontium);
myMap.set("yttrium", yttrium);
myMap.set("zirconium", zirconium);
myMap.set("niobium", niobium);
myMap.set("molybdenum", molybdenum);
myMap.set("technetium", technetium);
myMap.set("ruthenium", ruthenium);
myMap.set("rhodium", rhodium);
myMap.set("palladium", palladium);
myMap.set("silver", silver);
myMap.set("cadmium", cadmium);
myMap.set("indium", indium);
myMap.set("tin", tin);
myMap.set("antimony", antimony);
myMap.set("tellurium", tellurium);
myMap.set("iodine", iodine);
myMap.set("xenon", xenon);
myMap.set("cesium", cesium);
myMap.set("barium", barium);
myMap.set("hafnium", hafnium);
myMap.set("tantalum", tantalum);
myMap.set("tungsten", tungsten);
myMap.set("rhenium", rhenium);
myMap.set("osmium", osmium);
myMap.set("iridium", iridium);
myMap.set("platinum", platinum);
myMap.set("gold", gold);
myMap.set("mercury", mercury);
myMap.set("thallium", thallium);
myMap.set("lead", lead);
myMap.set("bismuth", bismuth);
myMap.set("polonium", polonium);
myMap.set("astatine", astatine);
myMap.set("radon", radon);
myMap.set("francium", francium);
myMap.set("radium", radium);
myMap.set("rutherfordium", rutherfordium);
myMap.set("dubnium", dubnium);
myMap.set("seaborgium", seaborgium);
myMap.set("bohrium", bohrium);
myMap.set("hassium", hassium);
myMap.set("meitnerium", meitnerium);
myMap.set("darmstadtium", darmstadtium);
myMap.set("roentgenium", roentgenium);
myMap.set("ununbium", ununbium);
myMap.set("ununtrium", ununtrium);
myMap.set("ununquadium", ununquadium);
myMap.set("ununpentium", ununpentium);
myMap.set("ununhexium", ununhexium);
myMap.set("ununseptium", ununseptium);
myMap.set("ununoctium", ununoctium);
myMap.set("lanthanum", lanthanum);
myMap.set("cerium", cerium);
myMap.set("praseodymium", praseodymium);
myMap.set("neodymium", neodymium);
myMap.set("promethium", promethium);
myMap.set("samarium", samarium);
myMap.set("europium", europium);
myMap.set("gadolinium", gadolinium);
myMap.set("terbium", terbium);
myMap.set("dysprosium", dysprosium);
myMap.set("holmium", holmium);
myMap.set("erbium", erbium);
myMap.set("thulium", thulium);
myMap.set("ytterbium", ytterbium);
myMap.set("lutetium", lutetium);
myMap.set("lawrencium", lawrencium);
myMap.set("nobelium", nobelium);
myMap.set("mendelevium", mendelevium);
myMap.set("fermium", fermium);
myMap.set("einsteinium", einsteinium);
myMap.set("californium", californium);
myMap.set("berkelium", berkelium);
myMap.set("curium", curium);
myMap.set("americium", americium);
myMap.set("plutonium", plutonium);
myMap.set("neptunium", neptunium);
myMap.set("uranium", uranium);
myMap.set("protactinium", protactinium);
myMap.set("thorium", thorium);
myMap.set("actinium", actinium);

//=========================================================================================================================================
//Editing anything below this line might break your skill.  
//=========================================================================================================================================
exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('AMAZON.HelpIntent');
    },
    'AskChemInfoIntent': function () {
        if(isAnswerSlotValid(this.event.request.intent)) {
        var elem = this.event.request.intent.slots.Element.value;
        var arrayholder = myMap.get(elem);
        var symbol = "The chemical symbol of " + elem + " is " + arrayholder[0];
        var atomicnumber = arrayholder[1];
        var atomicmass = arrayholder[2] + " atomic mass units";
        var speechOutput = GET_FACT_MESSAGE + elem + ". " + symbol + ". The atomic number is " + atomicnumber + ". The atomic mass is approximated to be " + atomicmass;
        var proton = ". The number of protons is " + arrayholder[3];
        var electron = ". The number of electrons in a neutral atom of " + elem +" is " + arrayholder[4];
        var neutron = ". The number of neutrons in the most common isotope of " + elem + " is " + arrayholder[5];
        var speechOutput1 = speechOutput + proton + electron + neutron;
        this.emit(':tell', speechOutput1);
        } else {
            this.emit(':tell', "I'm sorry, I didn't understand that, please ask again");
        }
        
    },
    'InvokedIntent': function() {
       if(isAnswerSlotValid(this.event.request.intent)) {
        var elem = this.event.request.intent.slots.Element.value;
        var arrayholder = myMap.get(elem);
        var symbol = "The chemical symbol of " + elem + " is " + arrayholder[0];
        var atomicnumber = arrayholder[1];
        var atomicmass = arrayholder[2] + " atomic mass units";
        var speechOutput = GET_FACT_MESSAGE + elem + ". " + symbol + ". The atomic number is " + atomicnumber + ". The atomic mass is approximated to be " + atomicmass;
        var proton = ". The number of protons is " + arrayholder[3];
        var electron = ". The number of electrons in a neutral atom of " + elem +" is " + arrayholder[4];
        var neutron = ". The number of neutrons in the most common isotope of " + elem + " is " + arrayholder[5];
        var speechOutput1 = speechOutput + proton + electron + neutron;
        this.emit(':tell', speechOutput1);
        } else {
            this.emit(':tell', "I'm sorry, I didn't understand that, please ask again");
        }  
    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = HELP_MESSAGE;
        var reprompt = HELP_REPROMPT;
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', STOP_MESSAGE);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', STOP_MESSAGE);
    },
    'Unhandled': function () {
        this.emit(':tell', "I'm sorry, I didn't understand that, please ask again");
        
    }

    
};
function isAnswerSlotValid(intent) {
    var answerSlotFilled = intent && intent.slots && intent.slots.Element && intent.slots.Element.value;
    var holderarray = Array.from(myMap.keys());
    console.log(intent.slots.Element.value);
    var keep = false;
    for(var i = 0; i < holderarray.length; i++) {
        if (intent.slots.Element.value == holderarray[i]){
            keep = true;
        }
    }
    console.log(keep);
    return keep && answerSlotFilled;
}