/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills Kit.
 * The Intent Schema, Custom Slots, and Sample Utterances for this skill, as well as
 * testing instructions are located at http://amzn.to/1LzFrj6
 *
 * For additional samples, visit the Alexa Skills Kit Getting Started guide at
 * http://amzn.to/1LGWsLG
 */

var Alexa = require('alexa-sdk');

var states = {
    STARTMODE: '_STARTMODE',                // Prompt the user to start or restart the game.
    ASKMODE: '_ASKMODE',                    // Alexa is asking user the questions.
    DESCRIPTIONMODE: '_DESCRIPTIONMODE'     // Alexa is describing the final choice and prompting to start again or quit
};


// Questions
var nodes = [{ "node": 1, "message": "Is your game Smash 64?", "yes": 6, "no": 2 },
             { "node": 2, "message": "Is your game Super Smash brothers Melee?", "yes": 29, "no": 4 },
             { "node": 4, "message": "Is your game Super Smash brothers Brawl?", "yes": 80, "no": 5 },
             { "node": 5, "message": "Is your game Super Smash Brothers for Wii U", "yes": 157, "no": 0 },
             {"node": 0, "message": "You might have a chosen a character not in the selection of games, please start over", "yes": 0, "no": 0},

    // questions for Smash 64
                { "node": 6, "message": "Is your character in the mario universe?", "yes": 7, "no": 12 },
                { "node": 7, "message": "Does your character have a mustache?", "yes": 8, "no": 11 },
            { "node": 8, "message": "Does your character wear red?", "yes": 9, "no": 10 },
            { "node": 12, "message": "Is your character human or elfish?", "yes": 13, "no": 20 },
            { "node": 13, "message": "Does your character shoot projectiles with a bow or a gun?", "yes": 14, "no": 17 },
            { "node": 14, "message": "Is your character secretly a girl?", "yes": 15, "no": 16 },
            { "node": 17, "message": "Does your character use magic?", "yes": 18, "no": 19 },
            { "node": 20, "message": "Is your character a pokemon?", "yes": 21, "no": 24 },
            { "node": 21, "message": "Does your character look cute and sing?", "yes": 22, "no": 23 },
            { "node": 24, "message": "Does your character have hair?", "yes": 25, "no": 28 },
            { "node": 25, "message": "Does your character carry a blaster?", "yes": 26, "no": 27 },
    // questions for Melee
            { "node": 29, "message": "Is your character human or elfish?", "yes": 30, "no": 59 },
            { "node": 30, "message": "Does your character hold a weapon?", "yes": 31, "no": 40 },
            { "node": 31, "message": "Is your character from legend of zelda?", "yes": 32, "no": 35 },
            { "node": 32, "message": "Is your character tiny?", "yes": 33, "no": 34 },
            { "node": 35, "message": "Does your character look like a prince or knight?", "yes": 36, "no": 39 },
            { "node": 36, "message": "Does your character use moves with fire?", "yes": 37, "no": 38 },
            { "node": 40, "message": "Does your character have facial hair?", "yes": 41, "no": 48 },
            { "node": 41, "message": "Does your character come from Mario?", "yes": 42, "no": 43 },
            { "node": 42, "message": "Does your character have an M. D.?", "yes": 44, "no": 45 },
            { "node": 45, "message": "Does your character wear green?", "yes": 46, "no": 47 },
            { "node": 48, "message": "Is your character a girl?", "yes": 49, "no": 56 },
            { "node": 49, "message": "Does your character wear a dress?", "yes": 50, "no": 53 },
            { "node": 50, "message": "Does your character usually get saved by an Italian plumber?", "yes": 51, "no": 52 },
            { "node": 53, "message": "Is your character a secret ninja?", "yes": 54, "no": 55 },
            { "node": 56, "message": "Does your character drive a race car?", "yes": 57, "no": 58 },
            { "node": 59, "message": "Is your character a pokemon?", "yes": 60, "no": 67 },
            { "node": 60, "message": "Does your character look like an electric mouse?", "yes": 61, "no": 64 },
            { "node": 61, "message": "Does your character run around outside with Ash ketchum?", "yes": 62, "no": 63 },
            { "node": 64, "message": "Is your character a clone?", "yes": 65, "no": 66 },
            { "node": 67, "message": "Does your character travel through space?", "yes": 68, "no": 71 },
            { "node": 68, "message": "Is your character a bird?", "yes": 69, "no": 70 },
            { "node": 71, "message": "Does your character swallow other characters?", "yes": 72, "no": 75 },
            { "node": 72, "message": "Does your character transform?", "yes": 73, "no": 74 },
            { "node": 75, "message": "Does your character look like some animal?", "yes": 77, "no": 76 },
            { "node": 77, "message": "Does your character look like a big spiky turtle?", "yes": 78, "no": 79 },

    // questions for Brawl
    { "node": 80, "message": "Is your character Pokemon?", "yes": 81, "no": 94 },
    { "node": 81, "message": "Is your character a form of a starter pokemon?", "yes": 82, "no": 87 },
    { "node": 82, "message": "Does your character fly?", "yes": 83, "no": 84 },
    { "node": 84, "message": "Is your character tiny?", "yes": 85, "no": 86 },
    { "node": 87, "message": "Is your character a human?", "yes": 88, "no": 89 },
    { "node": 89, "message": "Does your character float?", "yes": 90, "no": 91 },
    { "node": 91, "message": "Is your character blue?", "yes": 92, "no": 93 },
    { "node": 94, "message": "Does your character look human?", "yes": 95, "no": 130 },
    { "node": 95, "message": "Does your character carry a weapon?", "yes": 96, "no": 111 },
    { "node": 96, "message": "Does your character carry a sword?", "yes": 97, "no": 104 },
    { "node": 97, "message": "Is your character a from Fire Emblem?", "yes": 98, "no": 101 },
    { "node": 98, "message": "Does your character wear a head band?", "yes": 99, "no": 100 },
    { "node": 101, "message": "Is your character a mini version of another character?", "yes": 102, "no": 103 },
    { "node": 104, "message": "Does your character have a gun or blaster?", "yes": 105, "no": 108 },
    { "node": 105, "message": "Does your character wear a suit of armor?", "yes": 106, "no": 107 },
    { "node": 108, "message": "Does your character look like a pair of eskimos?", "yes": 109, "no": 110 },
    { "node": 111, "message": "Does your character have facial hair?", "yes": 112, "no": 119 },
    { "node": 112, "message": "Is your character a good guy?", "yes": 113, "no": 116 },
    { "node": 113, "message": "Is your character a tall, lanky italian plumber?", "yes":114, "no": 115 },
    { "node": 116, "message": "Is your character italian?", "yes": 117, "no": 118 },
    { "node": 119, "message": "Is your character a princess or does your character have an alter ego who's a princess?", "yes": 120, "no": 125 },
    { "node": 120, "message": "Does your character consistently get saved by italian plumbers?", "yes": 121, "no": 122 },
    { "node": 122, "message": "Does your character get saved by an elf?", "yes": 123, "no": 124 },
    { "node": 125, "message": "Is your character a little kid?", "yes": 126, "no": 129 },
    { "node": 126, "message": "Is your character blond?", "yes": 127, "no": 128 },
    { "node": 130, "message": "Does your character look like an animal?", "yes": 131, "no": 146 },
    { "node": 131, "message": "Does your character wear a shirt?", "yes": 132, "no": 139 },
    { "node": 132, "message": "Does your character fly through space?", "yes": 134, "no": 133 },
    { "node": 134, "message": "Does your character look like a bird?", "yes": 135, "no": 136 },
    { "node": 136, "message": "Is your character friends with another character that looks like a bird?", "yes": 137, "no": 138 },
    { "node": 139, "message": "Does your character have some article of clothing on?", "yes": 140, "no": 143 },
    { "node": 140, "message": "Does your character like bananas?", "yes": 141, "no": 142 },
    { "node": 143, "message": "Does your character like to kidnap princesses?", "yes": 144, "no": 145 },
    { "node": 146, "message": "Does your character come from the Kirby games?", "yes": 147, "no": 152 },
    { "node": 147, "message": "Does your character have a bunch of minions?", "yes": 148, "no": 149 },
    { "node": 149, "message": "Is your character a round pink blob?", "yes": 150, "no": 151 },
    { "node": 152, "message": "Is your character a robot?", "yes": 153, "no": 154 },
    { "node": 154, "message": "Does your character have small creatures following him?", "yes": 155, "no": 156 },



    // questions for Smash 4
    { "node": 157, "message": "Does your character carry a weapon of some kind?", "yes": 158, "no": 199 },
    { "node": 158, "message": "Is your character from the Fire Emblem Universe?", "yes": 159, "no": 170 },
    { "node": 159, "message": "Does your character have blue hair?", "yes": 160, "no": 165 },
    { "node": 160, "message": "Is your character a boy?", "yes": 161, "no": 164 },
    { "node": 161, "message": "Does your character wear a head band", "yes": 162, "no": 163 },
    { "node": 165, "message": "Does your character have red hair?", "yes": 166, "no": 167 },
    { "node": 167, "message": "Does your character use a magic tome to fight?", "yes": 168, "no": 169 },
    { "node": 170, "message": "Does your character have a bow?", "yes": 171, "no": 178 },
    { "node": 171, "message": "Does your character save Zelda?", "yes": 172, "no": 175 },
    { "node": 172, "message": "Is your character a small cartoon?", "yes": 173, "no": 174 },
    { "node": 175, "message": "Does your character wear black?", "yes": 176, "no": 177 },
    { "node": 178, "message": "Does your character carry a gun or blaster?", "yes": 179, "no": 190 },
    { "node": 179, "message": "Does your character travel through space?", "yes": 180, "no": 183 },
    { "node": 180, "message": "Is your character a furry fox?", "yes": 181, "no": 182 },
    { "node": 183, "message": "Is your character from metroid?", "yes": 184, "no": 187 },
    { "node": 184, "message": "Does your character wear a suit of armor?", "yes": 185, "no": 186 },
    { "node": 187, "message": "Does your character wear a suit of armor?", "yes": 188, "no": 189 },
    { "node": 190, "message": "Is your character round?", "yes": 191, "no": 194 },
    { "node": 191, "message": "Does your character carry a big hammer?", "yes":192, "no": 193 },
    { "node": 194, "message": "Is your character a pretty woman?", "yes": 195, "no": 196 },
    { "node": 196, "message": "Does your character have a weird looking sword??", "yes": 197, "no": 198 },
    { "node": 199, "message": "Does your character wear a shirt?", "yes": 200, "no": 237 },
    { "node": 200, "message": "Does your character have facial hair?", "yes": 201, "no": 212 },
    { "node": 201, "message": "Is your character an italian plumber?", "yes": 202, "no": 205 },
    { "node": 202, "message": "Is your character a little on the plump side?", "yes": 203, "no": 204 },
    { "node": 205, "message": "Is your character italian?", "yes": 206, "no": 209 },
    { "node": 206, "message": "Is your character a doctor?", "yes": 207, "no": 208 },
    { "node": 209, "message": "Is your character evil?", "yes": 210, "no": 211 },
    { "node": 212, "message": "Does your character wear something on their head?", "yes": 213, "no": 228 },
    { "node": 213, "message": "Does your character wear a crown?", "yes": 214, "no": 219 },
    { "node": 214, "message": "Does your character have a very small star friend?", "yes": 215, "no": 216 },
    { "node": 216, "message": "Does your character get saved by an Italian plumber?", "yes": 217, "no": 218 },
    { "node": 219, "message": "Does your character have big bulky muscles?", "yes": 220, "no": 223 },
    { "node": 220, "message": "Does your character know karate?", "yes": 221, "no": 222 },
    { "node": 223, "message": "Does your character have a bunch of minions?", "yes": 224, "no": 225 },
    { "node": 225, "message": "Does your character throw needles?", "yes": 226, "no": 227 },
    { "node": 228, "message": "Does your character like to punch things?", "yes": 229, "no": 232 },
    { "node": 229, "message": "Does your character wear a tank top?", "yes": 230, "no": 231 },
    { "node": 232, "message": "Does your character help people get fit?", "yes": 233, "no": 234 },
    { "node": 234, "message": "Does your character use magic?", "yes": 235, "no": 236 },
    { "node": 237, "message": "Is your character a pokemon?", "yes": 238, "no": 249 },
    { "node": 238, "message": "Does your character fly?", "yes": 239, "no": 244 },
    { "node": 239, "message": "Is your character dragon like?", "yes": 240, "no": 241 },
    { "node": 241, "message": "Is your character a cute pink puff ball?", "yes": 242, "no": 243 },
    { "node": 244, "message": "Does your character look like an electric rat?", "yes": 245, "no": 246 },
    { "node": 246, "message": "Is your pokemon a ninja?", "yes": 247, "no": 248 },
    { "node": 249, "message": "Is your character from Mario", "yes": 250, "no": 255 },
    { "node": 250, "message": "Is your character a bad guy?", "yes": 251, "no": 254 },
    { "node": 251, "message": "Is your character quite large?", "yes": 252, "no": 253 },
    { "node": 255, "message": "Does your character come from a game where they have lots of friends?", "yes": 256, "no": 261 },
    { "node": 256, "message": "Does your character like monkeys?", "yes": 257, "no": 258 },
    { "node": 258, "message": "Is your character very fast?", "yes": 259, "no": 260 },
    { "node": 261, "message": "Does your character swallow lots of things?", "yes": 262, "no": 265 },
    { "node": 262, "message": "Does your character transform?", "yes": 263, "no": 264 },
    { "node": 265, "message": "Is your character a robot?", "yes": 266, "no": 267 },


// Answers & descriptions
             { "node": 9, "message": "Mario", "yes": 0, "no": 0, "description": "Mario appears as a starter character in Super Smash Bros. He is considered an all-around character due to none of his attributes being higher than the others." },
             { "node": 10, "message": "Luigi", "yes": 0, "no": 0, "description": "Luigi appears in Super Smash Bros. as one of the four unlockable characters. He is a clone of Mario, keeping most of his moves and animations, though differing in terms of attributes."},
             { "node": 11, "message": "Yoshi", "yes": 0, "no": 0 , "description": "Yoshi is a starter character in Super Smash Bros. He is known for his unique double jump, shield and slew of low-lag, yet often powerful moves."},
             { "node": 15, "message": "Samus", "yes": 0, "no": 0 , "description": "Samus Aran is a starter character in Super Smash Bros.. As in her games, she fights inside the hi-tech, powerful Varia Suit, giving her a strong endurance to attacks as well as varied options for attack."},
             { "node": 16, "message": "Link", "yes": 0, "no": 0 , "description": "Link appears as a starter character in Super Smash Bros. He is the sole representative of The Legend of Zelda series. Link is perhaps the most well-equipped character with either long ranged and melee options of attack, with two projectiles (which would become three in later iterations), his long-reaching Master Sword and his Hookshot. "},
             { "node": 18, "message": "Ness", "yes": 0, "no": 0 , "description": "Ness is one of the main characters from the EarthBound franchise and appears as one of the four secret characters in Super Smash Bros."},
             { "node": 19, "message": "Captain Falcon", "yes": 0, "no": 0 , "description": "Captain Falcon is the main character from the F-Zero franchise, and appears in Super Smash Bros. as one of the four unlockable characters. "},
             { "node": 22, "message": "JigglyPuff", "yes": 0, "no": 0 , "description": "Jigglypuff is an unlockable character in Super Smash Bros.. Possibly included due to its popularity in the anime, Jigglypuff is notable for its similar appearance and nature to Kirby, and the fact that they share a lot of moves makes them semi-clones.."},
            { "node": 23, "message": "Pikachu", "yes": 0, "no": 0, "description": "Pikachu is a starter character in Super Smash Bros. It originates from the Pokémon series, being its recognizable mascot. Pikachu is generally a light, quick character, which would serve as the archetype for some other lightweight characters in the series." },
            { "node": 26, "message": "Fox", "yes": 0, "no": 0, "description": "Fox McCloud is the main character from the Star Fox series and appears as a starter character in Super Smash Bros.. He is known for his amazing movement speed, running and falling fast, as well as being equipped with a small Blaster and a reflector for defensive purposes. "},
            { "node": 27, "message": "Donkey Kong", "yes": 0, "no": 0 , "description": "Donkey Kong, written as DK, is a starter character in Super Smash Bros. He has slow, yet powerful attacks, like his trademark move: the Giant Punch. Due to this, his archetype has also inspired the archetype for most of the heavyweight characters in subsequent games, on which he has also appeared. "},
            { "node": 28, "message": "Kirby", "yes": 0, "no": 0 , "description": "Kirby is a starter character in Super Smash Bros.. He is known for being a small, light character with quick and often surprisingly long ranged attacks, as well as surprisingly strong moves and a great recovery.."},




            { "node": 33, "message": "Young Link", "yes": 0, "no": 0 , "description": "Young Link is a character in Super Smash Bros. Melee. He is a direct clone of Link, with some minor differences. Young Link has a very good approach due to some low lag aerials, a great Short Hop Fast Fall Technique and a good wavedash, as well as three projectiles."},
            { "node": 34, "message": "Link", "yes": 0, "no": 0 , "description": "Link is a starter character in Super Smash Bros. Melee. Link returns as a veteran character from the previous game, acting mostly the same as before, as a swordsman with powerful short range attacks and a wide variety of long range attacks."},
            { "node": 37, "message": "Roy", "yes": 0, "no": 0 , "description": "Roy is a secret character in Super Smash Bros. Melee. He is a clone of Marth, differentiated primarily by his sweetspots being located near the center of his blade rather than the tip. "},
            { "node": 38, "message": "Marth", "yes": 0, "no": 0 , "description": "Marth debuted in the first game of the Fire Emblem series, Fire Emblem: Shadow Dragon and the Blade of Light. Marth was placed in Super Smash Bros. Melee due to heavy requests from Japanese players; as his games had never been released outside of Japan prior to Melee, his character was among the most obscure in the game in other regions."},
            { "node": 39, "message": "Ice Climbers", "yes": 0, "no": 0, "description": "Ice Climbers are playable characters in Super Smash Bros. Melee. They rank 7th on the tier list (in the B tier), highly accredited to the usage of Wobbling and Desynching and the fact that the fighter is literally two-in-one, which helps the climbers rack up damage, combo, and KO opponents; this gives the Ice Climbers one of the best grab games in Melee." },
            { "node": 43, "message": "Ganondorf", "yes": 0, "no": 0, "description": "Ganondorf appears as an unlockable playable character in Super Smash Bros Melee. He is in his original Gerudo form as he appears in the more recent installments of the series. Instead of using magic or swords like in The Legend of Zelda series, Ganondorf is a clone of Captain Falcon, and as such, he fights in a brawler style similar to Captain Falcon, but in a slower, more powerful manner."},
            { "node": 44, "message": "Doctor Mario", "yes": 0, "no": 0 , "description": "Dr. Mario is an unlockable character in Super Smash Bros. Melee. This is his first 3D appearance as well as his first appearance in the Super Smash Bros. series, as he stems from a series of Mario puzzle games. As a clone of Mario, Dr. Mario and Mario have nearly identical movesets with obvious differences in attack physics."},
            { "node": 46, "message": "Luigi", "yes": 0, "no": 0 , "description": "Luigi is an unlockable character in Super Smash Bros. Melee. Luigi is markedly similar to Mario, though his moveset and attributes (such as traction and aerial mobility) are different in many ways, making him a semi-clone."},
            { "node": 47, "message": "Mario", "yes": 0, "no": 0 , "description": "Mario returns as a starter character in Super Smash Bros. Melee. He was announced at E3 2001. He also has a clone, Dr. Mario, whom with he shares a lot of attributes and special moves."},
            { "node": 51, "message": "Peach", "yes": 0, "no": 0 , "description": "Peach is a starter character in Super Smash Bros. Melee and it was her first appearance in the Super Smash Bros. series.Currently, Peach is 6th in the A tier, making her the highest ranked of any Mario character. Peach's float cancel gives her a fantastic aerial game."},
            { "node": 52, "message": "Zelda", "yes": 0, "no": 0 , "description": "Zelda is one of the more unique characters in the lineup for Super Smash Bros. Melee. Zelda's most notable traits are her array of powerful magical attacks and her unique ability to transform herself into her alter ego, Sheik."},
            { "node": 54, "message": "Sheik", "yes": 0, "no": 0 , "description": "Sheik is a starter character in Super Smash Bros. Melee. She transforms from Zelda by using her down special move (Transform), and can transform back. By holding the A button at the stage loading screen, Zelda will automatically transform into Sheik at the start of a match."},
            { "node": 55, "message": "Samus", "yes": 0, "no": 0, "description": "Samus Aran is a starter character in Super Smash Bros. Melee. Returning as a veteran from the previous game, Samus, similarly to Link, reprises her role as a short-ranged fighter with numerous ranged options. In addition, she received some powerful buffs, causing her to improve from a bottom-tiered character in Super Smash Bros. to a high-mid tiered character in Melee." },
            { "node": 57, "message": "Captain Falcon", "yes": 0, "no": 0, "description": "Captain Falcon currently ranks 8th out of 26 on the Melee tier list, in the B tier. While this is considered to be a minor drop compared to his previous placement in Smash 64, where he was ranked 3rd out of 12, he still ranks rather high likewise in the Smash 64 tier list because he retains his incredible comboing abilities; he has a fast falling speed and air speed, and the single fastest dash speed of all characters,."},
            { "node": 58, "message": "Ness", "yes": 0, "no": 0 , "description": "Ness is a default character in Super Smash Bros. Melee. Announced at E3 2001, he was originally going to be replaced by Lucas from Mother 3; the ultimate cancellation of the game for the Nintendo 64."},
            { "node": 62, "message": "Pikachu", "yes": 0, "no": 0 , "description": "Announced at E3 2001, Pikachu is a Pokémon and starter character in Super Smash Bros. Melee. Like Kirby and Ness, Pikachu was nerfed from the original to Melee, albeit not as strongly."},
            { "node": 63, "message": "Pichu", "yes": 0, "no": 0, "description": "Pichu is a Pokémon character in Super Smash Bros. Melee. It is unlocked by completing Event 37: Legendary Pokémon or by playing 200 vs. matches. Pichu is the baby pre-evolution of Pikachu, and in Melee, Pichu has a nearly identical moveset, making it a clone." },
            { "node": 65, "message": "Mewtwo", "yes": 0, "no": 0, "description": "Mewtwo is an unlockable character in Super Smash Bros. Melee. It is one of eleven playable characters that can be unlocked in the game.Mewtwo currently ranks 21st on the Melee tier list, in the F tier. While initially deemed the worst character in the game, the changing metagame of Melee caused Mewtwo to experience a rise of five places. "},
            { "node": 66, "message": "Jigglypuff", "yes": 0, "no": 0 , "description": "Jigglypuff is an unlockable character in Super Smash Bros. Melee from the Pokémon series, making a return from the first Super Smash Bros game. Jigglypuff retains most of its moves from Smash 64, though with some modifications."},
            { "node": 69, "message": "Falco", "yes": 0, "no": 0 , "description": "Falco is a hidden character in Super Smash Bros. Melee. He is a clone of Fox, with many of the moves. However, some of his moves have different properties, making their playstyles somewhat different."},
            { "node": 70, "message": "Fox", "yes": 0, "no": 0 , "description": "Fox is a playable starter character in Super Smash Bros. Melee. He is emblematic of speed and he can dominate foes with his rapid attacks, quick movement and overpowering offense in all areas of his game. He is placed 1st on the Melee tier list due to these advantages."},
            { "node": 73, "message": "Kirby", "yes": 0, "no": 0 , "description": "Kirby is a starter character in Super Smash Bros. Melee. Although tier-wise, he was the second-to-top character in Super Smash Bros. topped only by Pikachu, in Super Smash Bros. Melee, he has been severely nerfed."},
            { "node": 74, "message": "Yoshi", "yes": 0, "no": 0 , "description": "Yoshi is a starter character in Super Smash Bros. Melee. He was announced as a playable character at the E3 2001. He possesses a more realistic dinosaur crouching posture and mottled skin in Melee."},
            { "node": 76, "message": "Mister Game and Watch", "yes": 0, "no": 0 , "description": "Mr. Game & Watch is a character in Super Smash Bros. Melee. He was designed as a composite representation of various generic characters featured in the Game & Watch series, created by Gunpei Yokoi in 1980. He is the last character to be unlocked in the game."},
            { "node": 78, "message": "Bowser", "yes": 0, "no": 0, "description": "Bowser is a character in Super Smash Bros. Melee and is available from the start. Announced at E3 2001, a stronger form of Bowser also appears as the final boss in Adventure Mode. Bowser was added to the game because he won the official poll of desired newcomers for a potential second Smash game with 169 votes." },
            { "node": 79, "message": "Donkey Kong", "yes": 0, "no": 0, "description": "Donkey Kong is a default character in Super Smash Bros. Melee. He returns from the original Super Smash Bros., but with faster moves and agility, as well as an improved recovery."},


            { "node": 83, "message": "Charizard", "yes": 0, "no": 0 , "description": "Charizard is a playable character in Super Smash Bros. Brawl in a sense; it is one of three Pokémon that are played through the Pokémon Trainer, the other two being Squirtle and Ivysaur."},
            { "node": 85, "message": "Squirtle", "yes": 0, "no": 0 , "description": "Squirtle is a playable fighter in Super Smash Bros. Brawl in a sense; it is one of three Pokémon that are played through Pokémon Trainer, the other two being Ivysaur and Charizard. "},
            { "node": 86, "message": "Ivysaur", "yes": 0, "no": 0 , "description": "Ivysaur is a playable character in Super Smash Bros. Brawl in a sense; it is one of three Pokémon that are played through Pokémon Trainer, the other two being Squirtle and Charizard."},
            { "node": 88, "message": "Pokemon Trainer", "yes": 0, "no": 0 , "description": "Pokémon Trainer is a selectable character in Super Smash Bros. Brawl. His design is taken from that of Red, the male protagonist of the Generation I Pokémon games and their remakes. Rather than fighting directly as the Trainer, the player instead controls his three Pokémon, Squirtle, Ivysaur, and Charizard, all of which are starter Pokémon; and can switch between the three via use of his down special move, Pokémon Change."},
            { "node": 90, "message": "Jigglypuff", "yes": 0, "no": 0 , "description": "Jigglypuff is currently ranked 36th on the current Super Smash Bros. Brawl tier list in the low tier, which is an extreme drop from 5th in the Melee tier list. Jigglypuff possesses incredible air mobility, a good aerial game, one of the strongest edge guarding games, and one of the best recoveries in Brawl. "},
            { "node": 92, "message": "Lucario", "yes": 0, "no": 0 , "description": "Lucario is an unlockable character in Super Smash Bros. Brawl, originating from the Pokémon universe. Confirmation of Lucario's inclusion in Brawl was leaked before the game's release through a promotional video on the Japanese Wii website about sticker power ups. An evolution of Riolu, Lucario is a dual Fighting/Steel-type Pokémon, and is the first Pokémon to possess either of these types in a Smash game."},
            { "node": 93, "message": "Pikachu", "yes": 0, "no": 0, "description": "Pikachu is currently in the B Tier and holds 8th position, a slight increase to its C Tier status in Melee, where it is ranked 9th place. Pikachu has decent KOing power (though it can rely on Thunder in some situations), quick overall speed, very good recovery with many options as well as being unpredictable, good edgeguarding game with a quick and powerful neutral aerial and tricks that allow it get to the edge quickly, and a good grab and throw game (having two chaingrabs)." },
            { "node": 99, "message": "Ike", "yes": 0, "no": 0, "description": "Ike is a character appearing in Super Smash Bros. Brawl. Revealed in the Smash Bros. DOJO!! on August 1st, 2007, Ike is a newcomer to the franchise. He is the protagonist of Fire Emblem: Path of Radiance, and also appears in Fire Emblem: Radiant Dawn."},
            { "node": 100, "message": "Marth", "yes": 0, "no": 0 , "description": "Marth is a playable character in Super Smash Bros. Brawl. He was confirmed to be a playable character on the Smash Bros. DOJO on February 5, 2008. Despite being a hidden character, Marth appears in the game's opening video, standing back to back with Meta Knight."},
            { "node": 102, "message": "Toon Link", "yes": 0, "no": 0 , "description": "Toon Link is a playable character in Super Smash Bros. Brawl. His appearance is derived from the Link that appears in The Legend of Zelda: The Wind Waker and The Legend of Zelda: Phantom Hourglass. However, Toon Link looks slightly more realistic in Brawl than in The Wind Waker. "},
            { "node": 103, "message": "Link", "yes": 0, "no": 0 , "description": "Link returns as a playble character in Super Smash Bros. Brawl at E3 2006. He was one of the original 4 members to be confirmed as returning playable character at E3 2006, with the other three being Mario, Kirby, and Pikachu."},
            { "node": 106, "message": "Samus", "yes": 0, "no": 0 , "description": "Samus is a character that appears in Super Smash Bros. Brawl. Samus, like Zelda, has an alternate form she can transform into. Samus can change into Zero Suit Samus by inputting her up and down taunt rapidly, using her Final Smash, or by holding the L/R button, Z button, or the - button while selecting Samus on the character select screen."},
            { "node": 107, "message": "Snake", "yes": 0, "no": 0 , "description": "Snake known as Solid Snake in the character roll call and by other sources, is a character from Konami's Metal Gear universe who appears in Super Smash Bros. Brawl as one the two third party characters (the other being Sonic from Sega). Instead of using a gun like he usually does in his games, he was designed instead to use explosive-type weapons and close quarters combat from his own games."},
            { "node": 109, "message": "Ice Climbers", "yes": 0, "no": 0 , "description": "Ice Climbers return as playable charatcers from Melee. Ice climbers rank 2nd on the current tier list, making them the highest-ranking veteran in the game. This is primarily due to their extensive and intricate grab game that can completely shut down opponents once it begins."},
            { "node": 110, "message": "Pit", "yes": 0, "no": 0, "description": " Pit is a playable character appearing in Super Smash Bros. Brawl after a sixteen year absence from video games. He uses a bow and arrow as a weapon, which can also split into 2 small blades. The arrows it fires resemble beams of light, and the curve of the arrows' trajectory can be controlled by the player." },
            { "node": 114, "message": "Luigi", "yes": 0, "no": 0, "description": "Luigi is an unlockable character in Super Smash Bros. Brawl, who also appeared as an unlockable character in the previous two games, Super Smash Bros. and Super Smash Bros. Melee. "},
            { "node": 115, "message": "Mario", "yes": 0, "no": 0 , "description": "Mario is a playable character in Super Smash Bros. Brawl, who also appears in Super Smash Bros. Melee and the original Super Smash Bros. He is the icon of Nintendo and the Mario series."},
            { "node": 117, "message": "Wario", "yes": 0, "no": 0 , "description": "Wario makes his first playable appearance in Super Smash Bros. Brawl. Wearing his WarioWare outfit, Wario has an attack where he builds up flatulence over time and later releases a deadly fart called the Wario Waft."},
            { "node": 118, "message": "Ganondorf", "yes": 0, "no": 0, "description": "Ganondorf returns from Super Smash Bros. Melee in Super Smash Bros. Brawl as a playable character. The director of The Legend of Zelda, Eiji Aonuma, hinted at Ganondorf returning as a playable character when he stated that he sent Twilight Princess designs of him and Sheik to Masahiro Sakurai." },
            { "node": 121, "message": "Peach", "yes": 0, "no": 0, "description": "Peach is a starter character in Super Smash Bros. Brawl after returning from Super Smash Bros. Melee. She is ranked 19th out of 38 at the very center of the Brawl tier list, higher than any other Mario character (not including the spin-off universes), in the bottom of the high-mid tier."},
            { "node": 123, "message": "Zelda", "yes": 0, "no": 0 , "description": "Zelda is a playable fighter in Super Smash Bros. Brawl. The titular character of The Legend of Zelda universe, Zelda's model from The Legend of Zelda: Twilight Princess is reused in Brawl."},
            { "node": 124, "message": "Sheik", "yes": 0, "no": 0 , "description": "Sheik is a character in Super Smash Bros. Brawl. Sheik was originally hinted to return as a playable character when Eiji Aonuma, director of The Legend of Zelda stated he had sent the Twilight Princess designs of Sheik and Ganondorf to Sakurai."},
            { "node": 127, "message": "Lucas", "yes": 0, "no": 0 , "description": "Lucas is a playable character and newcomer in Super Smash Bros. Brawl, becoming the second installment in EarthBound characters. He is the main character of Mother 3, the Japan-only sequel to EarthBound. Lucas' special moves are similar to Ness', but his physical attacks are almost all completely different. He relies on his PSI powers far more than Ness, using them for all but his forward smash, up aerial, down tilt, and standard combo attacks."},
            { "node": 128, "message": "Ness", "yes": 0, "no": 0 , "description": "Ness is an unlockable character in Super Smash Bros. Brawl, and has appeared in every installment of the Smash Bros. series thus far. Ness is one of the only four unlockable characters to appear in the opening cinematic of Brawl. The three others sharing this attribute are Marth, Snake, and Sonic."},
            { "node": 129, "message": "Captain Falcon", "yes": 0, "no": 0 , "description": "Captain Falcon commonly known as Falcon or C. Falcon, appears as an unlockable character in Super Smash Bros. Brawl."},
            { "node": 133, "message": "Diddy Kong", "yes": 0, "no": 0 , "description": "Diddy Kong commonly known as just Diddy, is a character for Super Smash Bros. Brawl. He is unique, distinct among the cast for his charm and gaiety. Unlike in most Donkey Kong games and Mario spin-offs, where Diddy Kong has a cartoonish voice, Brawl has him using a high-pitched chimpanzee-like voice. He is also the first playable character to be introduced from the Donkey Kong universe since the original game."},
            { "node": 135, "message": "Falco", "yes": 0, "no": 0, "description": "Falco is a character appearing in Super Smash Bros. Brawl. He reprises his role from Super Smash Bros. Melee. He was confirmed to return as a playable character on February 20, 2008. Falco is ranked 7th out of 38 on the tier list, the lowest position of the A- Tier and top tier, and a slight drop from his Melee tier placement, where he was 2nd overall. Falco's Blaster shots are very fast, hard to punish, very long-ranged, transcendent, and allow him to camp and punish approaches easily." },
            { "node": 137, "message": "Fox", "yes": 0, "no": 0, "description": "Fox was confirmed for Super Smash Bros. Brawl at Nintendo World 2006. Fox is ranked 15th place on the tier list, placing him in the middle of the C tier, a noticeable nerf from his position at the top of the Melee tier list. Fox maintains his incredible movement, fast attack speed, high damage output, effective setup moves (especially his down aerial), and a very fast (8-frame) up smash with enough strength and reach to KO the majority of characters reliably under 100%."},
            { "node": 138, "message": "Wolf", "yes": 0, "no": 0 , "description": "Wolf is an unlockable character in Super Smash Bros. Brawl, who, along with Fox and Falco, originates from the Star Fox universe. Wolf's move set is quite different from Fox and Falco's, though his special moves, floor and ledge recovery animations, and Final Smash are similar to theirs."},
            { "node": 141, "message": "Donkey Kong", "yes": 0, "no": 0 , "description": "Donkey Kong is a character in Super Smash Bros. Brawl. He was first shown very briefly at the E3 2007 press conference. Donkey Kong is currently ranked 21st out of 38 on the tier list in the Mid tier. This is an improvement over his ranking in Melee, were he is ranked 17th out of 26 in the lower mid tier. Donkey Kong possesses a combination of incredible power with many great finishers (especially in his smash attacks), and incredible reach in his attacks."},
            { "node": 142, "message": "Sonic", "yes": 0, "no": 0 , "description": "Sonic, also referred to by his full name Sonic the Hedgehog (ソニック・ザ・ヘッジホッグ, Sonic the Hedgehog), is a character from SEGA who appears in Super Smash Bros. Brawl as one of the two third-party characters (the other being Snake from Konami). Sonic was the first unlockable character to be playable prior to the game's release."},
            { "node": 144, "message": "Bowser", "yes": 0, "no": 0 , "description": " Bowser is the primary antagonist of the Mario series, returning from his Super Smash Bros. series debut in Super Smash Bros. Melee. Bowser has new and original voice clips instead of recycling them from Super Mario 64. Currently, Bowser is 33rd out of 38 on the tier list, putting him in 3rd place on the F tier, a slight improvement from his 25th out of 26th position in Melee. Compared to his Melee incarnation, Bowser is a faster and more mobile character, at the expense of slightly less power."},
            { "node": 145, "message": "Yoshi", "yes": 0, "no": 0 , "description": "Yoshi is a character appearing in Super Smash Bros. Brawl. He is relatively unchanged from the previous games except for one thing - he can now use his Egg Throw as a recovery move (though it only gives him a small upwards boost). His smashes are less powerful, but his aerials and tilts are slightly more powerful."},
            { "node": 148, "message": "King Dedede", "yes": 0, "no": 0 , "description": "King Dedede also known as Dedede, DDD, and D3, is a playable character and a newcomer in Super Smash Bros. Brawl. He was confirmed on October 25, 2007 on the Smash Bros. DOJO!! site."},
            { "node": 150, "message": "Kirby", "yes": 0, "no": 0, "description": "Kirby returns as a playable character in Super Smash Bros. Brawl. He was confirmed for Brawl in the first preview shown at May 2006's E3 show. Of all the characters shown, Kirby appears to be almost completely unchanged graphically." },
            { "node": 151, "message": "Meta Knight", "yes": 0, "no": 0, "description": "Meta Knight commonly abbreviated as MK, is a character in Super Smash Bros. Brawl. Originally from the Kirby universe, Meta Knight joins the brawl as a starter newcomer who wields a sword, Galaxia, as his primary weapon.Meta Knight is notable for being at the top of the Super Smash Bros. Brawl tier list due to numerous advantages. His attacks generally have extremely high speed in terms of both startup and ending lag, and nearly all of his standard attacks have transcendent priority."},
            { "node": 153, "message": "Rob", "yes": 0, "no": 0 , "description": "R.O.B. is a newcomer in Super Smash Bros. Brawl. His full name is Robotic Operating Buddy and he is based on the R.O.B./Robot NES/Famicom peripheral. He was unveiled in a mass leak prior to the Japanese release of Brawl. R.O.B. was confirmed on the DOJO!! March 6, 2008."},
            { "node": 155, "message": "Olimar", "yes": 0, "no": 0, "description": "Olimar is a playable character from the Pikmin series in Super Smash Bros. Brawl. Olimar's fighter design in Brawl is collectively based of Captain Olimar himself, the main character of Pikmin, as well as his band of polychromatic Pikmin, coming in red, blue, yellow, purple, and white. Olimar is very weak on his own, and needs Pikmin to do smash attacks, most aerial attacks, and all throws. Each Pikmin has different effects for certain attacks." },
            { "node": 156, "message": "Mister Game and Watch", "yes": 0, "no": 0, "description": "Mr. Game & Watch is a veteran character in Super Smash Bros. Brawl, returning from Melee. At first, Mr. Game & Watch was indirectly revealed from a leaked copy of the game. However, he was officially confirmed on the Smash Bros. DOJO!! website on March 10, 2008, one day after Brawl was released in North America."},



    { "node": 162, "message": "Ike", "yes": 0, "no": 0 , "description": "Ike is a playable character in Super Smash Bros. 4. His return to the series was confirmed in a Director's Room Miiverse post on May 23rd, 2014, the same day that Fire Emblem: The Sacred Stones was released in North America in 2005."},
    { "node": 163, "message": "Marth", "yes": 0, "no": 0 , "description": "Marth is a playable character in Super Smash Bros. 4. Marth currently ranks 10th out of 58 characters on the tier list, in the A tier. This is a minor fall from his 5th place position out of 38 in Brawl. However, due to the expansion of tiers in SSB4, Marth remains a top tier character, as in all of his past appearances. Marth's positives include good overall mobility and relatively long disjointed range on all of his attacks."},
    { "node": 164, "message": "Lucina", "yes": 0, "no": 0 , "description": "Lucina is a playable character in Super Smash Bros. 4. She was confirmed during a live stream alongside Captain Falcon and Robin on the official Super Smash Bros. website on July 14th, 2014, making her the only unlockable character to be revealed before SSB4's release. Lucina is a clone of Marth, her ancestor within the Fire Emblem series. Although she was originally planned as an alternate costume for him, she was transitioned into being an entirely separate character later in development once her attacks were given differing traits"},
    { "node": 166, "message": "Roy", "yes": 0, "no": 0 , "description": "Roy is a playable character in Super Smash Bros. 4. Roy is currently ranked 44th out of 58 on the tier list, placing him in the E tier and making him the lowest ranking DLC character. Roy boasts good overall mobility and attack speed, owing to high dashing and air speeds, alongside fast-starting attacks that allow him to quickly react to openings."},
    { "node": 168, "message": "Robin", "yes": 0, "no": 0 , "description": "Robin is a playable newcomer in Super Smash Bros. 4. He was confirmed during a live stream, alongside Captain Falcon and Lucina, on the official Super Smash Bros. website on July 14th, 2014. Like in his home game Fire Emblem Awakening, players can select either male and female versions of Robin, similarly to Wii Fit Trainer, Villager, and Corrin."},
    { "node": 169, "message": "Corrin", "yes": 0, "no": 0 , "description": "Corrin is a character and newcomer in Super Smash Bros. 4, and is the sixth downloadable character announced. Corrin was announced alongside Bayonetta during the Super Smash Bros. - Final Video Presentation on December 15th, 2015, and both released on February 3rd, 2016. Like the Wii Fit Trainer, Villager, and Robin, players can select either male and female variants of Corrin as in Fire Emblem Fates."},
    { "node": 173, "message": "Toon Link", "yes": 0, "no": 0, "description": "Toon Link is a playable character in Super Smash Bros. 4. His return to the series was announced on September 26th, 2013 to commemorate The Legend of Zelda: The Wind Waker HD being released on the same day in Japan. Toon Link is currently ranked 20th out of 58 on the tier list, placing him in the B tier. This is roughly comparable to his placement in Brawl, where he was ranked 13th out of 38, although he is now assessed as a high-tier character instead of a mid-tier character. Toon Link has multiple projectiles, which grant him a powerful zoning game and enable him to follow up into different moves; his Bomb in particular is his most notable set-up for combos and KOs. " },
    { "node": 174, "message": "Link", "yes": 0, "no": 0, "description": "Link is a playable character in Super Smash Bros. 4. His return to the series was confirmed on June 11th, 2013 during the E3 2013 Nintendo Direct. Additionally, he was also among the first wave of amiibo that are compatible with SSB4. Link is currently ranked 39th out of 58 on the tier list, placing him in the D tier and making him the second lowest ranked mid-tier character. This is a vast improvement from his bottom-tier placement in Brawl, where he was ranked 35th out of 38."},
    { "node": 176, "message": "Dark Pit", "yes": 0, "no": 0 , "description": "Dark Pit is a playable character in Super Smash Bros. 4, being an unlockable newcomer. Dark Pit was teased before release, being shown in Palutena's reveal trailer, and officially confirmed by the Smash website on October 9th, 2014 alongside Dr. Mario, in a post-release announcement. He is a moveset clone of Pit and, like Dr. Mario and Lucina, Dark Pit was originally intended to be an alternate costume before being split off into his own character, the reason to this being due to the oddity of him wielding the Three Sacred Treasures and the Electroshock Arm being already modeled."},
    { "node": 177, "message": "Pit", "yes": 0, "no": 0 , "description": "Pit is a playable character in Super Smash Bros. 4. His return to the series was confirmed on June 11th, 2013 during the E3 2013 Nintendo Direct. Pit is currently ranked 30th out of 58 on the tier list, placing him in the C tier, tying him with his clone, Dark Pit, as they were treated as a single character during the most recent voting. This is a drop from his placement in Brawl, where he was ranked 17th out of 38."},
    { "node": 181, "message": "Fox", "yes": 0, "no": 0 , "description": "Fox returns as a playable character in Super Smash Bros. 4. He was one of the characters confirmed to return in the game during the E3 2013 trailers on June 11th, 2013. He was also among the first wave of amiibo figures that are compatible with SSB4. Fox is currently ranked 7th out of 58 characters in the tier list, in the A tier, which is the lower end of the top tier. This is a significant improvement from his previous position from Brawl where he was ranked 15th of 38 characters as an upper mid tier character."},
    { "node": 182, "message": "Falco", "yes": 0, "no": 0 , "description": "Falco returns as a playable character in Super Smash Bros. 4. Falco was officially confirmed on October 3rd, 2014, alongside Ness and Wario, coinciding with the North American and European release of Super Smash Bros. for Nintendo 3DS. Falco is currently ranked 50th out of 58th on the tier list, a significant drop from Brawl where he was ranked 7th out of 38, making this his worst placement in the series. The majority of Falco's moves have high speed and very favorable angles, granting him a strong combo game and juggling capabilities."},
    { "node": 185, "message": "Samus", "yes": 0, "no": 0 , "description": "Samus is a playable character in Super Smash Bros. 4. Her return to the series was confirmed in the E3 2013 trailers on June 11th, 2013, while she was also among the first wave of amiibo figures that are compatible with SSB4. However, unlike in Super Smash Bros. Brawl, Samus is no longer capable of transitioning into Zero Suit Samus, with the latter now becoming a standalone character. "},
    { "node": 186, "message": "Zero Suit Samus", "yes": 0, "no": 0 , "description": "Zero Suit Samus is a playable character in Super Smash Bros. 4. She was confirmed in the Super Smash Bros. Direct on April 8th, 2014, exactly a decade after Metroid: Zero Mission was released in Europe. Like Sheik, Zero Suit Samus is now a standalone character, which means that she cannot activate or deactivate her Power Suit under any circumstances."},
    { "node": 188, "message": "Mega Man", "yes": 0, "no": 0, "description": "Mega Man is a newcomer in Super Smash Bros. 4. He was announced at Nintendo's E3 2013 Direct Conference presentation for the game, becoming the first-revealed of the six third-party characters in the game along with SEGA's Sonic and Bayonetta, Bandai Namco's Pac-Man, fellow Capcom character Ryu, and Square Enix's Cloud. He does not widely use hand-to-hand combat, instead relying on the large arsenal of ranged weaponry he has amassed by defeating boss characters in his own games." },
    { "node": 189, "message": "Mii Gunner", "yes": 0, "no": 0, "description": "Mii Gunners are one of the three different types of Mii Fighters that appear in Super Smash Bros. 4, along with Mii Brawlers and Mii Swordfighters.The Mii Gunner is currently ranked 53rd out of 58 characters on the tier list, making them the highest ranking Mii fighter. Mii Gunner's positives include their fast attacks, wide range of projectiles making them very versatile in different situations, fast grab, and their superb range. However, they have some noticeable flaws. If using their default size and height, their mobility is very unimpressive"},
    { "node": 192, "message": "King Dedede", "yes": 0, "no": 0 , "description": "King Dedede is a playable character in Super Smash Bros. 4. His return to the series was announced on January 10th, 2014 to commemorate the release of Kirby: Triple Deluxe in Japan. King Dedede is currently ranked 52nd out of 58 on the tier list, placing him in the F tier and in the lower portion of the low-tier. This is a significant drop from his high-tier placement in Brawl, where he was ranked 12th out of 38."},
    { "node": 193, "message": "Meta Knight", "yes": 0, "no": 0 , "description": "Meta Knight is a playable character in Super Smash Bros. 4. After initially being teased as a Mii Fighter costume on August 11, 2014. Meta Knight is currently ranked 14th out of 58 on the tier list, placing him in the B tier, and making him the second highest ranking high-tier character. This is a noticeable drop from his top-tier placement in Brawl, where he was ranked 1st out of 38."},
    { "node": 195, "message": "Palutena", "yes": 0, "no": 0, "description": "Palutena is a playable character in Super Smash Bros. 4. She was revealed alongside the Mii Fighters and Pac-Man on June 10th, 2014 to attendees of the E3 2014 Super Smash Bros. roundtable. Palutena is currently ranked 42th out of 58 on the tier list, placing her in the E tier, and making her the second highest ranking low-tier character. Palutena has good overall mobility, which is especially evident on the ground, thanks to her fast walking and dashing speeds and high traction." },
    { "node": 197, "message": "Shulk", "yes": 0, "no": 0, "description": "Shulk is a playable character in Super Smash Bros. 4. Initially leaked alongside Bowser Jr. and Ganondorf via footage used by the ESRB. Shulk is currently ranked 38th out of 58 on the SSB4 tier list, placing him in the D tier. One of Shulk's greatest assets is his disjointed range, with the Monado giving him the longest overall reach of any weapon."},
    { "node": 198, "message": "Mii Sword Fighter", "yes": 0, "no": 0 , "description": "Mii Swordfighter is one of the three different types of Mii Fighters that appear in Super Smash Bros. 4, along with Mii Brawlers and Mii Gunners. Mii Swordfighter is ranked 57th out of 58 on the current tier list, placing them in bottom tier and making them the lowest ranked newcomer and Mii Fighter. The Mii Swordfighter has several noteworthy strengths, such as solid range due to a disjointed hitbox, respectable combo ability, and one of the game's fastest grabs."},
    { "node": 203, "message": "Mario", "yes": 0, "no": 0 , "description": "Mario is a playable character in Super Smash Bros. 4. He was confirmed on June 11th, 2013 during the E3 2013 Nintendo Direct. He was also one of the main subjects of the Developer's Direct for Super Smash Bros. later during E3 2013. He was among the first wave of amiibo figurines for SSB4. Mario is currently ranked 6th out of 58 characters on the tier list, in the A tier, which is the lower end of the top tier. This is his best tier placement to date."},
    { "node": 204, "message": "Luigi", "yes": 0, "no": 0 , "description": "Luigi is a playable character in Super Smash Bros. 4. As part of Nintendo's Year of Luigi, his return to the series was announced during the Nintendo Direct on August 7th, 2013. Luigi is currently ranked 26th out of 58 in the tier list, placing him in the C tier. This is a vast improvement over his placement in Brawl, where he was ranked 28th out of 38, and is his best proportional placement in the series. "},
    { "node": 207, "message": "Doctor Mario", "yes": 0, "no": 0 , "description": "Dr. Mario is a playable character in Super Smash Bros. 4. His return to the series was confirmed on October 9th, 2014 as part of a post-release announcement, during which Dark Pit was also confirmed. Like Dark Pit and Lucina, Dr. Mario was originally planned to be an alternate costume. However, all three were instead converted into being clones late in SSB4's development, with Masahiro Sakurai explaining that the reason for doing so in regard to Dr. Mario was in order to appeal to his fanbase from Super Smash Bros. Melee."},
    { "node": 208, "message": "Wario", "yes": 0, "no": 0 , "description": "Wario returns as a playable character in Super Smash Bros. 4. He was officially confirmed on October 3rd, 2014 alongside Ness and Falco, coinciding with the North American and European release of Super Smash Bros. for Nintendo 3DS. This time around, he is unlockable, as opposed to being available from the start in Brawl."},
    { "node": 210, "message": "Ganondorf", "yes": 0, "no": 0 , "description": "Ganondorf is a playable character in Super Smash Bros. 4. Alongside R.O.B., he was officially revealed as a playable veteran on October 15th, 2014. Ganondorf is currently ranked 53rd out of 58 on the tier list, placing him in the F tier. This is a slight improvement from his ranking in Brawl, where he was game's lowest-ranking character."},
    { "node": 211, "message": "Diddy Kong", "yes": 0, "no": 0, "description": "Diddy Kong is a playable character in Super Smash Bros. 4. Diddy Kong currently ranks 2nd out of 58 characters in the tier list, in the top end of the top tier, a slight rise from his equally top-tiered placement of 4th out of 38 in Brawl. Diddy Kong's strengths lie in his powerful comboing ability, with attacks flowing very well together as a result of their surprisingly long reach for a character of his size, quick frame data, and low knockback. " },
    { "node": 215, "message": "Rosalina", "yes": 0, "no": 0, "description": "Rosalina & Luma known simply as Rosalina (ロゼッタ, Rosetta) in the character customization menu and the Super Smash Bros. for Nintendo 3DS foldout, are playable characters in Super Smash Bros. 4. A duo consisting of Rosalina and a Luma, the player primarily controls Rosalina, while additional moves and inputs control the Luma's position and attacks. Luma (チコ, Chiko) is a member of the star-shaped species of the same name that is under the care of Rosalina. It fights in tandem with Rosalina, similarly to how Nana fights in tandem with Popo, and utilizes hit points (HP) like Captain Olimar's Pikmin do."},
    { "node": 217, "message": "Peach", "yes": 0, "no": 0 , "description": "Peach is a playable character in Super Smash Bros. 4. She was confirmed on September 12th, 2013, the day before the 28th anniversary of Super Mario Bros., the landmark NES game in which she debuted. She is among the first wave of compatible amiibo figures. Peach is currently ranked at 21st place out of 58 characters on the tier list, ranking in the lower end of the B tier; the high tier. This is an improvement from her previous 19th of 38 in Brawl, where she is the last character of the upper-mid-tier."},
    { "node": 218, "message": "Zelda", "yes": 0, "no": 0 , "description": "Zelda is a playable character in Super Smash Bros. 4. Zelda is currently ranked 55th out of 58 on the tier list, placing her in the F tier. This is a marginal improvement from her placement in Brawl, where she was ranked 37th out of 38, and results in her being assessed as a low-tier character instead of a bottom-tier character."},
    { "node": 221, "message": "Ryu", "yes": 0, "no": 0 , "description": "Ryu is a playable character and newcomer in Super Smash Bros. 4. As the fourth downloadable character announced, Ryu was revealed and released alongside veterans Lucas and Roy on June 14th, 2015. Ryu is the fourth of six playable third-party characters for the game, alongside Sega's Sonic and Bayonetta, Bandai Namco's Pac-Man, fellow Capcom representative Mega Man, and Square Enix's Cloud. Ryu is currently ranked 12th out of 58 on the tier list, placing him in the A tier and making him the lowest ranking top-tier character. The control input carryover from the Street Fighter series benefits Ryu immensely, with his tapped attacks being useful combo starters and his held attacks being great combo finishers or potent KO options."},
    { "node": 222, "message": "Captain Falcon", "yes": 0, "no": 0 , "description": "Captain Falcon returns as a playable character in Super Smash Bros. 4. Captain Falcon currently ranks 23rd on the SSB4 tier list, in the last spot of B tier. His placement is a vast improvement over his bottom tier 34th out of 38 ranking in Brawl."},
    { "node": 224, "message": "Olimar", "yes": 0, "no": 0 , "description": "Olimar is a playable character in Super Smash Bros. 4. Olimar is currently ranked 27th out of 58 on the tier list, placing him in the upper portion of the C tier. This is a significant drop from his top-tier placement in Super Smash Bros. Brawl, where he was ranked 3rd out of 38. As in Brawl, Olimar's Pikmin possess an impressive level of utility: they grant him respectable KO and damage racking potentials, as Olimar can use them to deal direct and/or indirect damage via his standard moves, and by having the Pikmin latch onto opponents via Pikmin Throw, respectively."},
    { "node": 226, "message": "Sheik", "yes": 0, "no": 0 , "description": "Sheik returns as a playable fighter in Super Smash Bros. 4. Sheik currently ranks 4th on the SSB4 tier list, ranking as the last character in the S tier, which is a striking improvement from her mid tiered 25th place out of 38 characters in Brawl. While not as overwhelmingly dominant as Meta Knight in Brawl, Sheik was near-universally considered the best competitive character in the early metagame of SSB4 due to her extremely fast and safe attacks."},
    { "node": 227, "message": "Ness", "yes": 0, "no": 0, "description": "Ness returns as a playable character in Super Smash Bros. 4. Ness was officially confirmed on October 3rd, 2014, alongside Falco and Wario. ess currently ranks 24th out of 58 characters on the tier list, placing him at the very start of the C tier and the top of mid tier. This is a vast improvement from his 26th out of 38 in Brawl, and his best placement compared to previous Smash Bros. games. " },
    { "node": 230, "message": "Little Mac", "yes": 0, "no": 0, "description": "Little Mac is a playable character in Super Smash Bros. 4. Little Mac is currently ranked 43rd out of 58 in the tier list, placing him in the upper portion of the E tier. As a ground-oriented fighter, Little Mac greatest strength lies in the sheer effectiveness of his ground game; in addition to his outstanding ground mobility, high traction and fast/long-ranged dodges, Little Mac possesses the overall fastest grounded moveset which also boast high utility, either through having combo ability, a high damage output, or strong KO potential. "},
    { "node": 231, "message": "Mii Brawler", "yes": 0, "no": 0 , "description": "Mii Brawlers are one of the three different types of Mii Fighters that appear in Super Smash Bros. 4, along with Mii Swordfighters and Mii Gunners. The Mii Brawler is currently ranked 56th out of 58 characters in the current tier list. Compared to the other Mii Fighters, Mii Brawlers boast formidable mobility, attack speed, and damage that is further strengthened by their great ground and air games, giving them a versatile combo game and excellent KOing ability once they find an opening."},
    { "node": 233, "message": "Wii Fit Trainer", "yes": 0, "no": 0, "description": "Wii Fit Trainer is a playable character in Super Smash Bros. 4. After initial reveal trailers, her status as a newcomer was revealed during E3 2013 on June 11th, 2013. She was one of the three newcomers announced at E3 2013, alongside Villager and Mega Man. A male version of Wii Fit Trainer was shown on October 31st, 2013, the release date for the trial version of Wii Fit U, and was later confirmed to be an alternate costume during the April 8th, 2014 Super Smash Bros. Direct. She was also among the first wave of amiibo figures compatible with SSB4." },
    { "node": 235, "message": "Lucas", "yes": 0, "no": 0, "description": "Lucas is a playable character in Super Smash Bros. 4. Initially absent as a playable character, Lucas' return to the series was revealed during a Nintendo Direct on April 1st, 2015. He was then made available as downloadable content on June 14th, 2015, alongside Roy and Ryu. Lucas is currently ranked 32nd out of 58 on the tier list, placing him in the C tier. This is a fairly noticeable improvement from his ranking in Brawl, where he was ranked 30th out of 38."},
    { "node": 236, "message": "Villager", "yes": 0, "no": 0 , "description": "Villager is a newcomer in Super Smash Bros. 4. Villager was revealed during E3 2013 on June 11th, 2013 during the first reveal trailer for Smash 4, and alongside other newcomers announced during E3 2013, Wii Fit Trainer and Mega Man. Similar to the Wii Fit Trainer, Robin, and Corrin, players are able to play as male and female versions of the Villager. There are four male and four female variations available. He was also among the first wave of amiibo figures that are compatible with SSB4."},
    { "node": 240, "message": "Charizard", "yes": 0, "no": 0 , "description": "Charizard is a playable character in Super Smash Bros. 4. Charizard is currently ranked 45th out of 58 on the tier list, placing it in the E tier, and making it the third highest ranked super heavyweight. This is a slight improvement from Pokémon Trainer's placement in Brawl, where he was ranked 29th out of 38"},
    { "node": 242, "message": "Jigglypuff", "yes": 0, "no": 0 , "description": "Jigglypuff is a playable character in Super Smash Bros. 4. Jigglypuff is currently ranked 58th on the tier list, placing it at the bottom the F tier and the entire tier list itself. This is a slight drop from its already near-bottom ranking in Brawl. "},
    { "node": 243, "message": "Mewtwo", "yes": 0, "no": 0 , "description": "Mewtwo is a playable character in Super Smash Bros. 4. Initially confirmed during the Super Smash Bros. for Wii U 50-Fact Extravaganza on October 23rd, 2014, Mewtwo was made available to the public for download on April 28th, 2015. It was available for free as early as April 15th, 2015. Mewtwo is ranked 9th out of 58 on the current tier list, placing it in the A tier. This is a vast improvement from its low-tier placement in Melee, where it was ranked 21st out of 26."},
    { "node": 245, "message": "Pikachu", "yes": 0, "no": 0 , "description": "Pikachu is a playable character in Super Smash Bros. 4. Its return to the series was confirmed on June 11th, 2013 during E3 2013, while it was also among the first wave of amiibo. Pikachu is currently ranked 15th out of 58 on the tier list, placing it in the B tier. This is a minor drop from its ranking of 8th out of 38 in Brawl, though its status as a high-tier character has remained intact. Pikachu's positives include its fast overall speed, excellent approach, good neutral and combo games, and excellent recovery."},
    { "node": 247, "message": "Greninja", "yes": 0, "no": 0 , "description": "Greninja is a playable character in Super Smash Bros. 4. It was revealed during the April 8th, 2014 Super Smash Bros. Direct, alongside fellow Pokémon representative Charizard. Greninja is currently ranked 22nd out of 58 on the tier list, placing it in the B tier. Greninja's greatest strength is its overall mobility: its walking, dashing and air speeds and its jumps are each among the top 10 within their respective categories. "},
    { "node": 248, "message": "Lucario", "yes": 0, "no": 0, "description": "Lucario is a playable character in Super Smash Bros. 4. Lucario is currently ranked 19th out of 58 on the tier list, placing it in the B tier. While this is a very small drop from its placement in Brawl, where it was ranked 11th out of 38, its placement renders it as a high-tier character in comparison to its mid-tier placement in Brawl." },
    { "node": 252, "message": "Bowser", "yes": 0, "no": 0, "description": "Bowser is a playable character in Super Smash Bros. 4. His return to the series was confirmed on June 11th, 2013 during E3 2013. Bowser is currently ranked 25th out of 58 on the tier list, placing him in the C tier. This makes him the second highest ranking mid-tier character, the highest ranking super heavyweight, and is a vast improvement from his placement in Brawl, where he was ranked 33rd out of 38."},
    { "node": 253, "message": "Bowser Junior", "yes": 0, "no": 0 , "description": "Bowser Jr. is a playable character in Super Smash Bros. 4. Alongside Mr. Game & Watch, Bowser Jr. was officially revealed during the Super Smash Bros. for Wii U: 50-Fact Extravaganza on October 23, 2014, being the second-to-last newcomer shown by an official source. Bowser Jr. is currently ranked 48th out of 58 on the tier list, placing him in the E tier. Bowser Jr. is notably the only character in the game who has disjointed hitboxes on all of his attacks. "},
    { "node": 254, "message": "Yoshi", "yes": 0, "no": 0 , "description": "Yoshi is a playable character in Super Smash Bros. 4. His return to the series was confirmed during the April 8th, 2014 Super Smash Bros. Direct, making him the last of the perfect-attendance crew to be announced. He was also among the first wave of amiibo figures. Yoshi is currently ranked 29th out of 58 on the tier list, placing him in the C tier, and directly in the middle of the entire tier list. This is a vast improvement from his placement in Super Smash Bros. Brawl, where he was ranked 27th out of 38."},
    { "node": 257, "message": "Donkey Kong", "yes": 0, "no": 0 , "description": "Donkey Kong is a playable character in Super Smash Bros. 4. His return to the series was confirmed on June 11th, 2013 during the E3 Nintendo Direct. Donkey Kong is currently ranked 28th out of 58 on the tier list, placing him in the C tier, and his best placement in the series to date. This makes him the second highest ranked super heavyweight and is an improvement from his placement in Brawl, where he was ranked 21st out of 38."},
    { "node": 259, "message": "Sonic", "yes": 0, "no": 0 , "description": "Sonic  is a playable character in Super Smash Bros. 4. His return to the series was announced during the Nintendo Direct on October 1st, 2013 to commemorate Sonic Lost World being released that month. Sonic is one of the six third-party characters in the game, alongside fellow Sega representative Bayonetta, Capcom's Mega Man and Ryu, Bandai Namco's Pac-Man, and Square Enix's Cloud. He was the second third-party character to be revealed in the game, and is the first and only third-party veteran in the series. "},
    { "node": 260, "message": "Duck Hunt", "yes": 0, "no": 0 , "description": "Duck Hunt, known as Duck Hunt Duo in the PAL version, are playable characters in Super Smash Bros. 4. Duck Hunt are currently ranked 37th out of 58 on the tier list, placing them in the D tier. Duck Hunt have a very capable zoning game thanks to their three versatile projectiles, with the remote controllable Trick Shot being especially useful. Their fast air speed and useful aerial attacks also grant them a decent air game, which in turn syncs well with their projectiles' ability to maintain stage control. "},
    { "node": 263, "message": "Kirby", "yes": 0, "no": 0 , "description": "Kirby is a playable character in Super Smash Bros. 4. He was confirmed on June 11th, 2013 during the E3 2013 Nintendo Direct. He was also among the first wave of amiibo figures that are compatible with SSB4. Kirby is currently ranked 47th out of 58 on the tier list, placing him in the E tier. This is a considerable drop from his placement in Brawl, where he was ranked 20th out of 38. Kirby possesses a great combo game: his up tilt, forward throw and down aerial are very good combo starters, with the latter also boasting guaranteed KO set-ups that are effective even against floaty characters, while his forward and up aerials are useful for partaking in a wall of pain and juggling, respectively. "},
    { "node": 264, "message": "Pac Man", "yes": 0, "no": 0, "description": "Pac-Man rendered in-game as PAC-MAN in non-Japanese versions and as PACMAN in the Japanese version, is a newcomer in Super Smash Bros. 4. After initially being revealed on June 10th, 2014 to attendees of the E3 2014 Super Smash Bros. roundtable, he was later confirmed to the public on Nintendo of America's Twitter account alongside Palutena and the Mii Fighters. Pac-Man is one of six third-party characters in SSB4, alongside Capcom's Mega Man and Ryu, Sega's Sonic and Bayonetta, and Square Enix's Cloud." },
    { "node": 266, "message": "ROB", "yes": 0, "no": 0, "description": "R.O.B. is a playable character in Super Smash Bros. 4. Alongside Ganondorf, his return to the series was officially confirmed on October 15th, 2014. R.O.B. is currently ranked 33rd out of 58 on the tier list, placing him in the lower portion of the C tier. This is a slight drop from his placement in Brawl, where he was ranked 18th out of 38. R.O.B. retains several of his strengths from Brawl: he has a strong zoning game courtesy of Robo Beam and Gyro, an excellent recovery courtesy of Robo Burner, a strong air game courtesy of all but one of his aerials having disjointed hitboxes, great mobility for a heavyweight, and a good grab game."},
    { "node": 267, "message": "Mister Game and Watch", "yes": 0, "no": 0 , "description": "Mr. Game & Watch is a playable character in Super Smash Bros. 4. After making a cameo in Pac-Man's trailer, Mr. Game & Watch was formally revealed on October 23rd, 2014. Mr. Game & Watch is currently ranked 40th out of 58 on the tier list, placing him at the bottom of the D tier and making him the lowest ranking mid-tier character. This is a drop from his ranking in Brawl, where he was ranked 16th out of 38. Mr. Game & Watch's strengths include great combo and air games and, despite being a lightweight, a high overall damage output on par with some heavyweights. "},

];

// this is used for keep track of visted nodes when we test for loops in the tree
var visited;

// These are messages that Alexa says to the user during conversation

// This is the intial welcome message
    var welcomeMessage = "Welcome to Name that Character Smash Edition, have you thought of a smash game and a playable character in that game?";

// This is the message that is repeated if the response to the initial welcome message is not heard
var repeatWelcomeMessage = "Say yes to start the game or no to quit.";

// this is the message that is repeated if Alexa does not hear/understand the reponse to the welcome message
var promptToStartMessage = "Say yes to continue, or no to end the game.";

// This is the prompt during the game when Alexa doesnt hear or understand a yes / no reply
var promptToSayYesNo = "Say yes or no to answer the question.";

// This is the response to the user after the final question when Alex decides on what group choice the user should be given
var decisionMessage = "I think your character is ";

// This is the prompt to ask the user if they would like to hear a short description of thier chosen profession or to play again
var playAgainMessage = "Say 'tell me more' to hear a short description for this character, or do you want to play again?";

// this is the help message during the setup at the beginning of the game
var helpMessage = "I will ask you some questions that will identify what character you have chosen. Want to start now?";

// This is the goodbye message when the user has asked to quit the game
var goodbyeMessage = "Ok, see you next time!";

var speechNotFoundMessage = "Could not find speech for node";

var nodeNotFoundMessage = "In nodes array could not find node";

var descriptionNotFoundMessage = "Could not find description for node";

var loopsDetectedMessage = "A repeated path was detected on the node tree, please fix before continuing";

var utteranceTellMeMore = "tell me more";

var utterancePlayAgain = "play again";

// the first node that we will use
var START_NODE = 1;

// --------------- Handlers -----------------------

// Called when the session starts.
exports.handler = function (event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(newSessionHandler, startGameHandlers, askQuestionHandlers, descriptionHandlers);
    alexa.execute();
};

// set state to start up and  welcome the user
var newSessionHandler = {
  'LaunchRequest': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', welcomeMessage, repeatWelcomeMessage);
  },'AMAZON.HelpIntent': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', helpMessage, helpMessage);
  },
  'Unhandled': function () {
    this.handler.state = states.STARTMODE;
    this.emit(':ask', promptToStartMessage, promptToStartMessage);
  }
};

// --------------- Functions that control the skill's behavior -----------------------

// Called at the start of the game, picks and asks first question for the user
var startGameHandlers = Alexa.CreateStateHandler(states.STARTMODE, {
    'AMAZON.ResumeIntent': function () {

        // ---------------------------------------------------------------
        // check to see if there are any loops in the node tree - this section can be removed in production code
        visited = [nodes.length];
        var loopFound = helper.debugFunction_walkNode(START_NODE);
        if( loopFound === true)
        {
            // comment out this line if you know that there are no loops in your decision tree
             this.emit(':tell', loopsDetectedMessage);
        }
        // ---------------------------------------------------------------

        // set state to asking questions
        this.handler.state = states.ASKMODE;

        // ask first question, the response will be handled in the askQuestionHandler
        var message = helper.getSpeechForNode(START_NODE);

        // record the node we are on
        this.attributes.currentNode = START_NODE;

        // ask the first question
        this.emit(':ask', message, message);
    },
    'AMAZON.PauseIntent': function () {
        // Handle No intent.
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
         this.emit(':ask', promptToStartMessage, promptToStartMessage);
    },
    'AMAZON.HelpIntent': function () {
        this.emit(':ask', helpMessage, helpMessage);
    },
    'Unhandled': function () {
        this.emit(':ask', promptToStartMessage, promptToStartMessage);
    }
});


// user will have been asked a question when this intent is called. We want to look at their yes/no
// response and then ask another question. If we have asked more than the requested number of questions Alexa will
// make a choice, inform the user and then ask if they want to play again
var askQuestionHandlers = Alexa.CreateStateHandler(states.ASKMODE, {

    'AMAZON.ResumeIntent': function () {
        // Handle Yes intent.
        helper.yesOrNo(this,'yes');
    },
    'AMAZON.PauseIntent': function () {
        // Handle No intent.
         helper.yesOrNo(this, 'no');
    },
    'AMAZON.HelpIntent': function () {
        this.emit(':ask', promptToSayYesNo, promptToSayYesNo);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
        // reset the game state to start mode
        this.handler.state = states.STARTMODE;
        this.emit(':ask', welcomeMessage, repeatWelcomeMessage);
    },
    'Unhandled': function () {
        this.emit(':ask', promptToSayYesNo, promptToSayYesNo);
    }
});

// user has heard the final choice and has been asked if they want to hear the description or to play again
var descriptionHandlers = Alexa.CreateStateHandler(states.DESCRIPTIONMODE, {

 'AMAZON.ResumeIntent': function () {
        // Handle Yes intent.
        // reset the game state to start mode
        this.handler.state = states.STARTMODE;
        this.emit(':ask', welcomeMessage, repeatWelcomeMessage);
    },
    'AMAZON.PauseIntent': function () {
        // Handle No intent.
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.HelpIntent': function () {
        this.emit(':ask', promptToSayYesNo, promptToSayYesNo);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', goodbyeMessage);
    },
    'AMAZON.StartOverIntent': function () {
        // reset the game state to start mode
        this.handler.state = states.STARTMODE;
        this.emit(':ask', welcomeMessage, repeatWelcomeMessage);
    },
    'DescriptionIntent': function () {
        //var reply = this.event.request.intent.slots.Description.value;
        //console.log('HEARD: ' + reply);
        helper.giveDescription(this);
      },

    'Unhandled': function () {
        this.emit(':ask', promptToSayYesNo, promptToSayYesNo);
    }
});

// --------------- Helper Functions  -----------------------

var helper = {

    // gives the user more information on their final choice
    giveDescription: function (context) {

        // get the speech for the child node
        var description = helper.getDescriptionForNode(context.attributes.currentNode);
        var message = description + ', ' + repeatWelcomeMessage;

        context.emit(':ask', message, message);
    },

    // logic to provide the responses to the yes or no responses to the main questions
    yesOrNo: function (context, reply) {

        // this is a question node so we need to see if the user picked yes or no
        var nextNodeId = helper.getNextNode(context.attributes.currentNode, reply);

        // error in node data
        if (nextNodeId == -1)
        {
            context.handler.state = states.STARTMODE;

            // the current node was not found in the nodes array
            // this is due to the current node in the nodes array having a yes / no node id for a node that does not exist
            context.emit(':tell', nodeNotFoundMessage, nodeNotFoundMessage);
        }

        // get the speech for the child node
        var message = helper.getSpeechForNode(nextNodeId);

        // have we made a decision
        if (helper.isAnswerNode(nextNodeId) === true) {

            // set the game state to description mode
            context.handler.state = states.DESCRIPTIONMODE;

            // append the play again prompt to the decision and speak it
            message = decisionMessage + ' ' + message + ' ,' + playAgainMessage;
        }

        // set the current node to next node we want to go to
        context.attributes.currentNode = nextNodeId;

        context.emit(':ask', message, message);
    },

    // gets the description for the given node id
    getDescriptionForNode: function (nodeId) {

        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].node == nodeId) {
                return nodes[i].description;
            }
        }
        return descriptionNotFoundMessage + nodeId;
    },

    // returns the speech for the provided node id
    getSpeechForNode: function (nodeId) {

        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].node == nodeId) {
                return nodes[i].message;
            }
        }
        return speechNotFoundMessage + nodeId;
    },

    // checks to see if this node is an choice node or a decision node
    isAnswerNode: function (nodeId) {

        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].node == nodeId) {
                if (nodes[i].yes === 0 && nodes[i].no === 0) {
                    return true;
                }
            }
        }
        return false;
    },

    // gets the next node to traverse to based on the yes no response
    getNextNode: function (nodeId, yesNo) {
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].node == nodeId) {
                if (yesNo == "yes") {
                    return nodes[i].yes;
                }
                return nodes[i].no;
            }
        }
        // error condition, didnt find a matching node id. Cause will be a yes / no entry in the array but with no corrosponding array entry
        return -1;
    },

    // Recursively walks the node tree looking for nodes already visited
    // This method could be changed if you want to implement another type of checking mechanism
    // This should be run on debug builds only not production
    // returns false if node tree path does not contain any previously visited nodes, true if it finds one
    debugFunction_walkNode: function (nodeId) {

        console.log("Walking node: " + nodeId);

        if( helper.isAnswerNode(nodeId) === true) {
            // found an answer node - this path to this node does not contain a previously visted node
            // so we will return without recursing further

            // console.log("Answer node found");
             return false;
        }

        // mark this question node as visited
        if( helper.debugFunction_AddToVisited(nodeId) === false)
        {
            // node was not added to the visited list as it already exists, this indicates a duplicate path in the tree
            console.log(nodeID);
            return true;
        }

        // console.log("Recursing yes path");
        var yesNode = helper.getNextNode(nodeId, "yes");
        var duplicatePathHit = helper.debugFunction_walkNode(yesNode);

        if( duplicatePathHit === true){
            return true;
        }

        // console.log("Recursing no");
        var noNode = helper.getNextNode(nodeId, "no");
        duplicatePathHit = helper.debugFunction_walkNode(noNode);

        if( duplicatePathHit === true){
            return true;
        }

        // the paths below this node returned no duplicates
        return false;
    },

    // checks to see if this node has previously been visited
    // if it has it will be set to 1 in the array and we return false (exists)
    // if it hasnt we set it to 1 and return true (added)
    debugFunction_AddToVisited: function (nodeId) {

        if (visited[nodeId] === 1) {
            // node previously added - duplicate exists
            // console.log("Node was previously visited - duplicate detected");
            return false;
        }

        // was not found so add it as a visited node
        visited[nodeId] = 1;
        return true;
    }
};
